const Q_FLOW = "Quantified Flow",
	Q_FLOW_SYMBOL = " Ψ ";

class QFlow extends QTab {
	constructor(id = window.id.get(), parent = null, attributes = [], code = "", variable = null) {
		super(id, parent, attributes, code, variable);
	}

	get symbol() {
		return Q_FLOW_SYMBOL;
	}

	getType() {
		return Q_FLOW;
	}

	save() {
		var Qflow = super.save();
		Qflow.class = Item.TYPES.Q_FLOW;
		return Qflow;
	}

}