const Q_PARALLEL_COMPOSITION = "Quantified Parallel Composition",
	Q_PARALLEL_COMPOSITION_SYMBOL = " || ";

class QParallelComposition extends QTab {

	constructor(id = window.id.get(), parent = null, attributes = [], code = "", variable = null) {
		super(id, parent, attributes, code, variable);
	}

	get symbol() {
		return Q_PARALLEL_COMPOSITION_SYMBOL;
	}

	getType() {
		return Q_PARALLEL_COMPOSITION;
	}

	save() {
		var Qparallel_composition = super.save();
		Qparallel_composition.class = Item.TYPES.Q_PARALLEL_COMPOSITION;
		return Qparallel_composition;
	}
}