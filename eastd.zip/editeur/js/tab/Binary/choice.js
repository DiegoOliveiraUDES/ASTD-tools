
const CHOICE = "Choice",
	CHOICE_SYMBOL = " | ";

class Choice extends Tab {
	constructor(id = window.id.get(), parent = null, attributes = [], code = "") {
		super(id, parent, attributes, code);
	}

	toHtml() {
		return CHOICE_SYMBOL;
	}

	getType() {
		return CHOICE;
	}

	get choicePanel() {
		var that = this;
		return {
			createPlayMode: function() {
				var container = document.createElement("div"),
					sideLabel = document.createElement("div");

				if (window.project.lastJsonObj !== undefined && window.project.lastJsonObj !== null) {
					var parentLabel = that.parent.tabs.length > 1 ? that.label : that.parent.label,
					 choiceObj = window.project.getJsonObjByType(window.project.lastJsonObj.top_level_astd, CHOICE, parentLabel);
					if (choiceObj !== null && choiceObj.side !== null) {
						sideLabel.textContent = "Side: " + choiceObj.side + ".";
					} else {
						sideLabel.textContent = "Side: No side yet.";
					}
				} else {
					sideLabel.textContent = "Side: No side yet.";
				}

				[sideLabel].forEach((component) => {
					container.appendChild(component);
				});
				return container;
			}
		};
	}

	toPanel() {
		return this.defaultBinaryPanel([], this.choicePanel.createPlayMode)();
	}

	save() {
		var choice = super.save();
		choice.class = Item.TYPES.CHOICE;
		return choice;
	}

	export(min_domain, max_domain, parameter_name, test_parameter, iD, index, external_parameter_name) {
		return super.binaryExport(min_domain, max_domain, parameter_name, test_parameter, iD, index, external_parameter_name);
	}

}