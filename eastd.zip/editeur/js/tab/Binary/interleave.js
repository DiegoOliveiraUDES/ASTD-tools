const INTERLEAVE = "Interleave",
	INTERLEAVE_SYMBOL = " ||| ";

class Interleave extends Tab {

	constructor(id = window.id.get(), parent = null, attributes = [], code = "") {
		super(id, parent, attributes, code);
	}

	toHtml() {
		return INTERLEAVE_SYMBOL;
	}

	getType() {
		return INTERLEAVE;
	}

	toPanel() {
		return this.defaultBinaryPanel()();
	}

	save() {
		var interleave = super.save();
		interleave.class = Item.TYPES.INTERLEAVE;
		return interleave;
	}

	load(interleave) {
		super.load(interleave);
	}

	export(min_domain, max_domain, parameter_name, test_parameter, iD, index, external_parameter_name) {
		return super.binaryExport(min_domain, max_domain, parameter_name, test_parameter, iD, index, external_parameter_name);
	}

}