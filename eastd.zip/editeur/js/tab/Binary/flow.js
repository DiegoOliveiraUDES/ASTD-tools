
const FLOW = "Flow",
	FLOW_SYMBOL = " Ψ ";

class Flow extends Tab {
	constructor(id = window.id.get(), parent = null, attributes = [], code = "") {
		super(id, parent, attributes, code);
	}

	toHtml() {
		return FLOW_SYMBOL;
	}

	getType() {
		return FLOW;
	}

	toPanel() {
		return this.defaultBinaryPanel()();
	}

	save() {
		var choice = super.save();
		choice.class = Item.TYPES.FLOW;
		return choice;
	}

	export(min_domain, max_domain, parameter_name, test_parameter, iD, index, external_parameter_name) {
		return super.binaryExport(min_domain, max_domain, parameter_name, test_parameter, iD, index, external_parameter_name);
	}

}