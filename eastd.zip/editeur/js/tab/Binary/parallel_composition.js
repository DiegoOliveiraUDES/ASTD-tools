const PARRALLEL_COMPOSITION = "Parallel Composition",
	PARRALLEL_COMPOSITION_SYMBOL = " || ";

class ParallelComposition extends Tab {

	constructor(id = window.id.get(), parent = null, attributes = [], code = "") {
		super(id, parent, attributes, code);
	}

	toHtml() {
		return PARRALLEL_COMPOSITION_SYMBOL;
	}

	getType() {
		return PARRALLEL_COMPOSITION;
	}

	toPanel() {
		return this.defaultBinaryPanel()();
	}

	save() {
		var parallel_composition = super.save();
		parallel_composition.class = Item.TYPES.PARALLEL_COMPOSITION;
		return parallel_composition;
	}

	load(parallel_composition) {
		super.load(parallel_composition);
	}

	export(min_domain, max_domain, parameter_name, test_parameter, iD, index, external_parameter_name) {
		return super.binaryExport(min_domain, max_domain, parameter_name, test_parameter, iD, index, external_parameter_name);
	}
}